<?php

namespace JoomDonation\Plugin\Installer\DmsUpdateDomain\Extension;

use Joomla\CMS\Event\Installer\BeforePackageDownloadEvent;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Uri\Uri;
use Joomla\Event\EventInterface;
use Joomla\Event\SubscriberInterface;

defined('_JEXEC') or die;

final class DmsUpdateDomain extends CMSPlugin implements SubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return ['onInstallerBeforePackageDownload' => 'addCustomerDomain'];
    }

    public function addCustomerDomain(EventInterface $event): void
    {
        $storeUrl = trim((string) $this->params->get('store_url', ''));

        if ($storeUrl === '' || empty($_SERVER['HTTP_HOST'])) {
            return;
        }

        // Joomla 4.4 passes the download URL as the first argument of a generic event.
        $url = $event instanceof BeforePackageDownloadEvent
            ? $event->getUrl()
            : $event->getArgument(0, '');

        if ($url === '') {
            return;
        }

        $store = new Uri($storeUrl);
        $download = new Uri(str_replace('&amp;', '&', $url));

        if (strtolower((string) $store->getScheme()) !== 'https'
            || !$store->getHost()
            || strtolower((string) $download->getScheme()) !== 'https'
            || strcasecmp($store->getHost(), (string) $download->getHost()) !== 0
            || ((int) $store->getPort() ?: 443) !== ((int) $download->getPort() ?: 443)
            || $download->getPath() !== rtrim((string) $store->getPath(), '/') . '/index.php'
            || $download->getVar('option') !== 'com_dms'
            || $download->getVar('task') !== 'download_update_package') {
            return;
        }

        $domain = Uri::getInstance()->getHost();

        if (!$domain) {
            return;
        }

        $download->setVar('domain', strtolower($domain));
        $url = $download->toString();

        if ($event instanceof BeforePackageDownloadEvent) {
            $event->updateUrl($url);
        } else {
            $event->setArgument(0, $url);
        }
    }
}
