<?php

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Version;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use JoomDonation\Plugin\Installer\DmsUpdateDomain\Extension\DmsUpdateDomain;

defined('_JEXEC') or die;

return new class implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            static function (Container $container): PluginInterface {
                $config = (array) PluginHelper::getPlugin('installer', 'dmsupdatedomain');

                if ((new Version())->isCompatible('5.4.0')) {
                    return new DmsUpdateDomain($config);
                }

                $dispatcher = $container->get(DispatcherInterface::class);

                return new DmsUpdateDomain($dispatcher, $config);
            }
        );
    }
};
